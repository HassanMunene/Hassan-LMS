0x02. AirBnB clone - MySQL
